
<?php 
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
  $loggedin= true;
}
else{
  $loggedin = false;
}
echo '<header class="header fixed-top">
<a href="#"><img src="logo.png" alt=""></a>

<nav>
    <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="product.php">Products</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="video.php">Projects</a></li>
        <li><a href="contact.php">Contact</a></li>';

      if(!$loggedin){
      echo ' <li><a href="/Interior Design/loginSystem/login.php">Login</a></li>';
      }
      if($loggedin){
      echo ' <li><a href="/Interior Design/loginSystem/logout.php">Logout</a></li>';
    }
       
      
    echo '</ul>
    </nav>

    <div class="fas fa-bars"></div>
    
</header>';
?>